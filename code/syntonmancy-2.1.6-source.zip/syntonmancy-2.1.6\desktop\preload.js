const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('zijianDesktop', {
  isDesktop: true,
  platform: process.platform,
  notify(payload) {
    if (!payload || typeof payload !== 'object') return;
    ipcRenderer.send('zijian:notify', {
      title: String(payload.title || '字势静兼'),
      body: String(payload.body || ''),
      chatId: payload.chatId ? String(payload.chatId) : '',
    });
  },
  onOpenChat(callback) {
    if (typeof callback !== 'function') return () => {};
    const handler = (_event, chatId) => callback(String(chatId || ''));
    ipcRenderer.on('zijian:open-chat', handler);
    return () => ipcRenderer.removeListener('zijian:open-chat', handler);
  },
  backupInfo() { return ipcRenderer.invoke('backup:info'); },
  chooseBackupFolder() { return ipcRenderer.invoke('backup:choose-folder'); },
  setBackupFolder(folder) { return ipcRenderer.invoke('backup:set-folder', String(folder || '')); },
  saveBackupFile(folder, filename, content) {
    return ipcRenderer.invoke('backup:write', { folder: String(folder || ''), filename: String(filename || ''), content: String(content || '') });
  },
  openBackupFolder(folder) { return ipcRenderer.invoke('backup:open-folder', String(folder || '')); },
  quit() {
    ipcRenderer.send('zijian:quit');
  },
});
