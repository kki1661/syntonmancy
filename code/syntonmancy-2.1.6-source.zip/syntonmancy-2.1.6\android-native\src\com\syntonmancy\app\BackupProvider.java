package com.syntonmancy.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileNotFoundException;

public class BackupProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return "application/json";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        try {
            File base = new File(getContext().getFilesDir(), "backups");
            String name = uri.getLastPathSegment();
            if (name == null || name.contains("/") || name.contains("\\")) {
                throw new FileNotFoundException("invalid backup name");
            }
            File file = new File(base, name);
            String basePath = base.getCanonicalPath() + File.separator;
            if (!file.getCanonicalPath().startsWith(basePath)) {
                throw new FileNotFoundException("invalid backup path");
            }
            return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (FileNotFoundException error) {
            throw error;
        } catch (Exception error) {
            throw new FileNotFoundException(error.getMessage());
        }
    }
}
