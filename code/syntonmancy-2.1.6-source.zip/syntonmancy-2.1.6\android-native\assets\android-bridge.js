(function () {
  const native = window.AndroidBridge;

  function call(name, args) {
    return new Promise(function (resolve, reject) {
      try {
        if (!native || typeof native[name] !== 'function') {
          reject(new Error('Android bridge not ready: ' + name));
          return;
        }
        resolve(native[name].apply(native, args || []));
      } catch (error) {
        reject(error);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    const style = document.createElement('style');
    style.textContent = '#changeBackupFolderBtn,#openBackupFolderBtn{display:none!important}';
    document.head.appendChild(style);
  });

  window.zijianDesktop = {
    isDesktop: true,
    platform: 'android',
    supportsFolderChoice: false,
    notify: function () {},
    onOpenChat: function () { return function () {}; },
    backupInfo: function () {
      return call('backupInfo').then(function (value) {
        try { return JSON.parse(value || '{}'); } catch (error) { return {}; }
      });
    },
    chooseBackupFolder: function () { return call('chooseBackupFolder'); },
    setBackupFolder: function (folder) { return call('setBackupFolder', [folder]); },
    saveBackupFile: function (folder, filename, content) {
      return call('saveBackupFile', [folder, filename, content]);
    },
    openBackupFolder: function () { return call('openBackupFolder'); },
    shareBackup: function (filename, content) {
      return call('shareBackup', [filename, content]);
    },
    quit: function () {},
  };
})();
