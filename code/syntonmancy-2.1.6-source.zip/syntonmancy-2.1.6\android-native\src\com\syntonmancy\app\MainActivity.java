package com.syntonmancy.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(Intent.createChooser(intent, "选择照片"), FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception error) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private File backupDir() {
        File dir = new File(getFilesDir(), "backups");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    private String safeName(String name) {
        String value = name == null ? "backup.json" : name;
        value = value.replace("\\", "_").replace("/", "_").replace("..", "_");
        if (!value.toLowerCase().endsWith(".json")) {
            value = value + ".json";
        }
        return value;
    }

    private File writeBackup(String filename, String content) throws Exception {
        File file = new File(backupDir(), safeName(filename));
        FileOutputStream out = new FileOutputStream(file, false);
        try {
            out.write((content == null ? "" : content).getBytes(StandardCharsets.UTF_8));
        } finally {
            out.close();
        }
        return file;
    }

    public final class AndroidBridge {
        @JavascriptInterface
        public String backupInfo() {
            try {
                JSONObject info = new JSONObject();
                info.put("configuredFolder", "应用私有目录 / backups");
                info.put("defaultFolder", "应用私有目录 / backups");
                info.put("appDir", "应用私有目录");
                info.put("appBackupDir", "应用私有目录 / backups");
                info.put("fallbackBackupDir", "应用私有目录 / backups");
                info.put("userData", "应用私有目录");
                return info.toString();
            } catch (Exception error) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String chooseBackupFolder() {
            return "";
        }

        @JavascriptInterface
        public String setBackupFolder(String folder) {
            return "false";
        }

        @JavascriptInterface
        public String saveBackupFile(String folder, String filename, String content) {
            try {
                File file = writeBackup(filename, content);
                return file.getAbsolutePath();
            } catch (Exception error) {
                return "";
            }
        }

        @JavascriptInterface
        public String openBackupFolder() {
            return "false";
        }

        @JavascriptInterface
        public String shareBackup(String filename, String content) {
            try {
                final File file = writeBackup(filename, content);
                final Uri uri = Uri.parse("content://com.syntonmancy.app.backups/backups/" + file.getName());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("application/json");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "分享备份到微信文件传输助手或百度网盘"));
                    }
                });
                return "ok";
            } catch (Exception error) {
                return "error";
            }
        }

        @JavascriptInterface
        public void notify(String title, String body) {
        }

        @JavascriptInterface
        public void onOpenChat() {
        }

        @JavascriptInterface
        public void quit() {
        }
    }
}
