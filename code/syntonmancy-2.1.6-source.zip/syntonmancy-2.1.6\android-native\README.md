﻿# 字势静兼 Android 测试版

## APK

- `字势静兼-2.1.6-android-debug.apk`
- debug 签名，可直接侧载安装
- minSdk 24 / targetSdk 34
- 包名 `com.syntonmancy.app`

安装时 Android 会提示“未知来源应用”，允许当前文件管理器安装即可。

## 2.1.6 图片改动

- 日记新建/编辑支持最多 12 张图片
- 聊天一次最多分享 3 张图片
- 照片只作为得字解意 30% 的弱参考
- 日记评论不读取日记文字或图片，只按凭空得到的字写

## 账号名找回

登录页提供「找回账号名」：列出这台设备上的所有本机账号名，选中后填入账号框；密码仍需用户自己记住，不提供密码重置。

## 当前功能

- 单文件 HTML 通过 WebView 运行
- 聊天、得字解句、登录、年龄确认
- 日记、收藏
- 照片选择
- 自动/手动备份写入应用私有目录 `files/backups`
- 备份通过 Android 系统分享面板发送到微信文件传输助手、百度网盘等
- 无存储权限
- 无微信/百度 SDK，无需外部审批

## 限制

- 没有 Windows 托盘
- 没有后台主动聊天
- 没有系统通知
- 不能自选备份文件夹
- 卸载应用会删除应用私有目录中的备份
- 数据与 Windows 桌面版不互通；用备份 JSON 迁移
- Android 版还没有在真机上完整验证 API 的 CORS 和文件选择器

## 构建

源码在 `android-native/`：

- `src/` Java WebView 壳和分享 Provider
- `assets/index.html` 当前应用
- `assets/android-bridge.js` 原生桥
- `AndroidManifest.xml`
- `res/` 图标和名称

当前 APK 由 Android SDK build-tools 36、platform 35、JDK 21 直接编译，不依赖 Gradle。
